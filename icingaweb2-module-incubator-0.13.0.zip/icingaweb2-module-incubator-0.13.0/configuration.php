<?php

$this->provideJsFile('loader.js');
$this->provideJsFile('combined.js');
